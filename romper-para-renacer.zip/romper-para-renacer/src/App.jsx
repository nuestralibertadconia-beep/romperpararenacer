import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";

const VIDEO_SRC = "https://cdn.coverr.co/videos/coverr-woman-looking-at-the-sea-7992/1080p.mp4";
const PRICE_TEXT = "$15.990 ARS";

function useCountdown(durationMs) {
  const [remaining, setRemaining] = useState(durationMs);

  useEffect(() => {
    const end = Date.now() + durationMs;
    function tick() {
      const ms = Math.max(0, end - Date.now());
      setRemaining(ms);
    }
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [durationMs]);

  const hrs = Math.floor(remaining / (1000 * 60 * 60));
  const mins = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
  const secs = Math.floor((remaining % (1000 * 60)) / 1000);

  return { hrs, mins, secs, remaining };
}

function Particles({ count = 24 }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let w = (canvas.width = innerWidth);
    let h = (canvas.height = innerHeight);
    const particles = [];

    function rand(min, max) {
      return Math.random() * (max - min) + min;
    }

    for (let i = 0; i < count; i++) {
      particles.push({
        x: rand(0, w),
        y: rand(0, h),
        r: rand(1, 3.5),
        vx: rand(-0.2, 0.2),
        vy: rand(-0.15, 0.15),
        alpha: rand(0.3, 0.9),
        drift: rand(-0.1, 0.1)
      });
    }

    let raf;
    function draw() {
      ctx.clearRect(0, 0, w, h);
      for (let p of particles) {
        p.x += p.vx + p.drift;
        p.y += p.vy;
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) p.y = h + 10;
        if (p.y > h + 10) p.y = -10;

        ctx.beginPath();
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 6);
        g.addColorStop(0, `rgba(255,230,170,${p.alpha})`);
        g.addColorStop(1, `rgba(255,200,120,${p.alpha * 0.05})`);
        ctx.fillStyle = g;
        ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    }
    draw();

    function onResize() {
      w = canvas.width = innerWidth;
      h = canvas.height = innerHeight;
    }
    window.addEventListener("resize", onResize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
    };
  }, [count]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 2,
        pointerEvents: "none",
        mixBlendMode: "screen"
      }}
    />
  );
}

export default function App() {
  const [showOffer, setShowOffer] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const countdown = useCountdown(24 * 60 * 60 * 1000);

  useEffect(() => {
    const t = setTimeout(() => setShowOffer(true), 2200);
    return () => clearTimeout(t);
  }, []);

  function onBuyEbook(e) {
    e.preventDefault();
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2500);
  }

  return (
    <div className="app-root" style={{ fontFamily: "'Inter', system-ui, -apple-system, 'Poppins', sans-serif" }}>
      <video
        autoPlay
        muted
        loop
        playsInline
        style={{
          position: "fixed",
          inset: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          zIndex: 0,
          filter: "brightness(0.55) saturate(0.95)"
        }}
      >
        <source src={VIDEO_SRC} type="video/mp4" />
      </video>

      <div
        style={{
          position: "fixed",
          inset: 0,
          background:
            "linear-gradient(180deg, rgba(30,20,18,0.35) 0%, rgba(30,20,18,0.20) 25%, rgba(255,230,210,0.06) 75%)",
          zIndex: 1
        }}
      />

      <Particles count={28} />

      <main
        style={{
          position: "relative",
          zIndex: 3,
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "36px 20px",
          textAlign: "center",
          color: "#fff"
        }}
      >
        <div style={{ maxWidth: 980, width: "100%" }}>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2 }}
            style={{ fontSize: "clamp(28px, 5vw, 56px)", marginBottom: 16, fontWeight: 700 }}
          >
            Romper para Renacer
          </motion.h1>

          <motion.div
            initial="hidden"
            animate="visible"
            variants={{ visible: { transition: { staggerChildren: 3 } } }}
            style={{ marginBottom: 18 }}
          >
            {[
              "A veces hay que romperse para volver a ser…",
              "El dolor no fue el final, fue el principio.",
              "Tu vida empieza ahora."
            ].map((t, i) => (
              <motion.p
                key={i}
                variants={{
                  hidden: { opacity: 0 },
                  visible: { opacity: 1, transition: { duration: 1.8 } }
                }}
                style={{ fontSize: "clamp(16px, 2vw, 20px)", fontStyle: "italic", color: "rgba(249,243,240,0.95)", margin: "10px 0" }}
              >
                {t}
              </motion.p>
            ))}
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.8 }}
            style={{ color: "rgba(249,243,240,0.9)", marginBottom: 26, fontSize: "16px" }}
          >
            Guía íntima para reencontrarte, sanar y elegirte con valentía.
          </motion.p>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 3.2 }}>
            <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
              <a
                href="#ebook"
                onClick={onBuyEbook}
                style={{
                  display: "inline-block",
                  background: "#e07a5f",
                  color: "#fff",
                  padding: "12px 28px",
                  borderRadius: 12,
                  fontWeight: 700,
                  textDecoration: "none",
                  boxShadow: "0 12px 30px rgba(224,122,95,0.18)"
                }}
              >
                Comprar ahora — {PRICE_TEXT}
              </a>

              <a
                href="#1a1"
                style={{
                  display: "inline-block",
                  border: "2px solid rgba(255,255,255,0.12)",
                  color: "#fff",
                  padding: "10px 22px",
                  borderRadius: 12,
                  textDecoration: "none",
                  fontWeight: 600
                }}
              >
                Sesión 1:1
              </a>
            </div>

            <div style={{ marginTop: 18 }}>
              <AnimatePresence>
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  style={{
                    display: "inline-flex",
                    gap: 12,
                    alignItems: "center",
                    background: "rgba(224,122,95,0.14)",
                    padding: "8px 14px",
                    borderRadius: 999,
                    color: "#fff",
                    fontWeight: 600
                  }}
                >
                  <span>⏳ Compra en 24h y accedés gratis a</span>
                  <strong style={{ padding: "6px 10px", background: "rgba(0,0,0,0.12)", borderRadius: 8 }}>Comunidad Renacer</strong>
                </motion.div>
              </AnimatePresence>

              <div style={{ marginTop: 10, color: "rgba(255,255,255,0.9)", fontWeight: 600 }}>
                <CountdownDisplay {...countdown} />
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 30, opacity: 0 }}
            transition={{ duration: 0.4 }}
            style={{
              position: "fixed",
              right: 20,
              bottom: 20,
              zIndex: 40,
              background: "#111827",
              color: "#fff",
              padding: "12px 18px",
              borderRadius: 12,
              boxShadow: "0 10px 28px rgba(0,0,0,0.4)"
            }}
          >
            ✔️ Simulación: te dirigimos al checkout (placeholder).
          </motion.div>
        )}
      </AnimatePresence>

      <footer style={{ position: "relative", zIndex: 3, color: "rgba(255,255,255,0.75)", textAlign: "center", padding: "26px 12px" }}>
        © 2025 Romper para Renacer — Todos los derechos reservados
      </footer>
    </div>
  );
}

function CountdownDisplay({ hrs, mins, secs }) {
  return (
    <div style={{ display: "flex", gap: 10, justifyContent: "center", alignItems: "center", marginTop: 6 }}>
      <TimeBox label="Horas" value={hrs} />
      <TimeBox label="Min" value={mins} />
      <TimeBox label="Seg" value={secs} />
    </div>
  );
}

function TimeBox({ label, value }) {
  const padded = String(value).padStart(2, "0");
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{ background: "rgba(255,255,255,0.06)", padding: "8px 12px", borderRadius: 8, minWidth: 58, fontWeight: 700 }}>
        {padded}
      </div>
      <div style={{ fontSize: 12, marginTop: 6, color: "rgba(255,255,255,0.78)" }}>{label}</div>
    </div>
  );
}
